import React from 'react';
import { Text, View } from 'react-native';

export default function HomeScreen() {
  return (
    <View>
      <Text className="text-4xl font-[#ffccff]">HomeScreen</Text>
    </View>
  );
}