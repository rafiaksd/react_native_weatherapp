import React from 'react';
import { Text, View } from 'react-native';
import "../global.css";

export default function HomeScreen() {
  return (
    <View>
      <Text className="text-4xl font-[#ffccff]">HomeScreen i mean ig a changea</Text>
    </View>
  );
}